import pandas as pd
import re

# Load your existing raw CSV
df = pd.read_csv("rfq_output.csv")  # Or use your latest raw file

structured_data = []

for raw_text in df["RawText"]:
    text = str(raw_text).replace('\n', ' | ')  # Flatten newlines
    lines = [part.strip() for part in text.split('|') if part.strip()]
    
    title = ""
    quantity = ""
    unit = ""
    location = ""
    date_posted = ""
    buyer = ""

    # Extract title (first long text with "Dear" or long product string)
    for line in lines:
        if not title and len(line) > 25 and "Dear" in line:
            title = line
            break

    # Extract quantity
    for i, line in enumerate(lines):
        if "Quantity Required" in line and i+2 < len(lines):
            quantity = lines[i+1]
            unit = lines[i+2]
            break

    # Extract location
    for i, line in enumerate(lines):
        if "Posted in:" in line and i+1 < len(lines):
            location = lines[i+1]
            break

    # Extract date
    for i, line in enumerate(lines):
        if "Date Posted:" in line and i+1 < len(lines):
            date_posted = lines[i+1]
            break

    # Extract buyer
    for line in lines:
        if "Email Confirmed" in line and "|" in raw_text:
            # Try to extract name before 'Email Confirmed'
            parts = raw_text.split("Email Confirmed")[0].split("|")
            if len(parts) >= 2:
                buyer = parts[-2].strip()
            break

    structured_data.append({
        "Title": title,
        "Quantity": quantity,
        "Unit": unit,
        "Location": location,
        "Date Posted": date_posted,
        "Buyer Name": buyer
    })

# Save the cleaned structured output
output_df = pd.DataFrame(structured_data)
output_df.to_csv("rfq_output_cleaned.csv", index=False)

print("✅ Improved cleaning done. Check rfq_output_cleaned.csv")
