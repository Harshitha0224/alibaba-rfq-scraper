from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import pandas as pd
import time
import zipfile

# Set up Chrome in headless mode
options = Options()
options.add_argument("--headless")
options.add_argument("--disable-gpu")
service = Service("chromedriver.exe")  # Must be in same folder

driver = webdriver.Chrome(service=service, options=options)

def scrape_page(page_number):
    url = f"https://sourcing.alibaba.com/rfq/rfq_search_list.htm?country=AE&recently=Y&page={page_number}"
    driver.get(url)
    time.sleep(4)  # Give JS content time to load

    # Grab ALL text inside RFQ blocks (even if class names change)
    rfq_blocks = driver.find_elements(By.CSS_SELECTOR, "div[class*='rfq-item']")
    data = []

    for block in rfq_blocks:
        try:
            text = block.text.strip().replace('\n', ' | ')
            if text:
                data.append({"RawText": text})
        except:
            continue

    return data

# Scrape first 3 pages
all_data = []
for page in range(1, 4):
    print(f"Scraping page {page}...")
    all_data.extend(scrape_page(page))

# Save to CSV
df = pd.DataFrame(all_data)
csv_file = "rfq_output.csv"
df.to_csv(csv_file, index=False)

# Zip everything
zip_file = "alibaba_rfq_output.zip"
with zipfile.ZipFile(zip_file, 'w') as zipf:
    zipf.write("alibaba_rfq_scraper_simple.py")
    zipf.write(csv_file)

print("✅ Done. Check rfq_output.csv and alibaba_rfq_output.zip.")

driver.quit()